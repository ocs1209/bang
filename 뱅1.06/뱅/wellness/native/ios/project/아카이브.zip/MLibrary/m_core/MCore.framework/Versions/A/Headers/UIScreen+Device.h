//
//  UIScreen+Device.h
//

#import <UIKit/UIKit.h>

@interface UIScreen (Device)

- (CGRect)deviceBounds;

@end
