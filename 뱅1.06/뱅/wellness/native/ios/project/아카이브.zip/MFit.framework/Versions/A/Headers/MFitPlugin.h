//
//  MFitPlugin.h
//

#import <Foundation/Foundation.h>

@interface MFitPlugin : MPlugin

+ (MFitPlugin *)getInstance;

@end

#define PLUGIN_CLASS    MFitPlugin
#define PLUGIN_BUNDLE   @"MFit.bundle"

#define PGResource(res) [PLUGIN_BUNDLE appendPath:res]
#define PGLocalizedString(key, comment) [PLUGIN_CLASS localizedStringForKey:(key)]
