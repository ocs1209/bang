//
//  FitManager.h
//  MDebug
//
//  Created by ProgDesigner on 2015. 9. 30..
//
//

#import <Foundation/Foundation.h>

@interface FitManager : NSObject

- (void)startUpdating;
//- (void)synchronize;

+ (FitManager *)defaultManager;

@end
