//
//  AppDelegate+MPush.h
//  MDebug
//
//  Created by ProgDesigner on 2015. 7. 20..
//
//

#import <Foundation/Foundation.h>
#import "AppDelegate.h"

@interface AppDelegate(MPush)

- (void)application:(UIApplication *)application didFinishLaunchingWithOptionsForPushService:(NSDictionary *)launchOptions;

@end
