//
//  SleepSummaryData.m
//  Wellness
//
//  Created by OGGU on 2016. 6. 16..
//
//

#import "SleepSummaryData.h"

@implementation SleepSummaryData

@dynamic idx;

@dynamic sync_cnt;

@dynamic sync_val;

@dynamic sync_avg;

@dynamic soso_cnt;

@dynamic soso_val;

@dynamic bad_cnt;

@dynamic bad_val;

@dynamic good_cnt;

@dynamic good_val;

@end
