//
//  HisotorySampleData.m
//  Wellness
//
//  Created by OGGU on 2016. 6. 10..
//
//

#import "HistorySampleData.h"

@implementation HisotorySampleData

@dynamic idx;

@dynamic step_datetime;

@dynamic step_date;

@dynamic time;

@dynamic type;

@dynamic value;

@dynamic etc1;

@dynamic etc2;

@dynamic etc3;

@end