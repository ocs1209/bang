//
//  AppDelegate+Facebook.h
//  MDebug
//
//  Created by ProgDesigner on 2015. 7. 20..
//
//

#import "AppDelegate.h"

@interface AppDelegate(Facebook)

@end
