//
//  MHybridViewController.h
//

#import <Foundation/Foundation.h>
#import <MFit/HistoryInterface.h>

@interface PPHybridViewController : PPWebViewController

@end
